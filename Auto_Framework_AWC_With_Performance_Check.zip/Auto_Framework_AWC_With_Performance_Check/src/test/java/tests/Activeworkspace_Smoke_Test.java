package tests;

import base.PerformanceTestBase;
import listeners.TestListener;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchPage;
import pages.UserSettingsPage;
import pages.WorkflowPage;
import utils.PerformanceUtil;
import utils.TestDataStore;

@Listeners(TestListener.class)

public class Activeworkspace_Smoke_Test extends PerformanceTestBase  {

    @Test
    public void activeWorkspaceBasicFlow() {

    
    loginToActiveWorkspace();  

    HomePage home = new HomePage(driver);
    Assert.assertTrue(home.isHomeDisplayed(), "Home page not loaded");

    UserSettingsPage settings = new UserSettingsPage(driver);

    PerformanceUtil.measure("Change User Settings", () -> {
    settings.changeUserSettings(
            prop.getProperty("group"),
            prop.getProperty("role"),
            prop.getProperty("project"));
    });
    
    SearchPage search = new SearchPage(driver);
    WorkflowPage workflow = new WorkflowPage(driver);

    String itemId = TestDataStore.createdItemID;

    waitForPageLoad();

    PerformanceUtil.measure("Search Item", () -> {
    search.searchItem(itemId, "Parts");
    });


    PerformanceUtil.measure("Open Search Result", () -> {
    search.openSearchedResult(itemId);
    });


    PerformanceUtil.measure("Workflow Assignment", () -> {
    workflow.startWorkflow("Remove Status");
    });

    System.out.println("Active Workspace basic flow automated successfully");
}


}
