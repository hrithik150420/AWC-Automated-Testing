package tests;

public @interface Test1 {

}
