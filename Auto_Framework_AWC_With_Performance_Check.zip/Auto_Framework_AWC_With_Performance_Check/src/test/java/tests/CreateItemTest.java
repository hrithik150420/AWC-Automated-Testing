package tests;

import base.Setup_File;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import pages.ItemCreationPage;
import utils.PerformanceUtil;

public class CreateItemTest extends Setup_File {

    @Test
    public void createPartItem()  {

        logInfo("Logging into Active Workspace");
        PerformanceUtil.measure("Login", () -> {
        loginToActiveWorkspace();
        });


        logInfo("Opening Create Item dialog");
        ItemCreationPage item = new ItemCreationPage(driver);

        By homeFolderButton = By.xpath("//button[@title='Home']");
        wait.until(ExpectedConditions.elementToBeClickable(homeFolderButton)).click();

        logInfo("Creating Part item");
        PerformanceUtil.measure("Create Part Item", () -> {
        item.createPart("Part", "Test Part");
        });
    }

}
