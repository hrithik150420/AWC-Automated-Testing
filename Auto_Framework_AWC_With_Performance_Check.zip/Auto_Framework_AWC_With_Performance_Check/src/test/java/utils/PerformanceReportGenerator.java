package utils;

import java.io.*;
import java.util.*;

public class PerformanceReportGenerator {

    public static void generateReport() {

        String csvFile = "performance_report.csv";
        String htmlFile = "performance_dashboard.html";

        Map<String, List<Double>> functionTimes = new HashMap<>();

        try {

            BufferedReader reader = new BufferedReader(new FileReader(csvFile));
            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                String functionName = data[0];
                double timeMs = Double.parseDouble(data[1]);

                double timeSeconds = timeMs / 1000;

                functionTimes
                        .computeIfAbsent(functionName, k -> new ArrayList<>())
                        .add(timeSeconds);
            }

            reader.close();

            List<String> functions = new ArrayList<>();
            List<Double> avgTimes = new ArrayList<>();
            List<Integer> executions = new ArrayList<>();

            for (String function : functionTimes.keySet()) {

                List<Double> times = functionTimes.get(function);

                double sum = 0;

                for (double t : times) {
                    sum += t;
                }

                double avg = sum / times.size();

                functions.add(function);
                avgTimes.add(Math.round(avg * 100.0) / 100.0);
                executions.add(times.size());
            }

            FileWriter writer = new FileWriter(htmlFile);

            writer.write("<html><head>");
            writer.write("<title>Automation Performance Dashboard</title>");
            writer.write("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");

            writer.write("<style>");
            writer.write("body{font-family:Arial;background:#f5f5f5;text-align:center;}");
            writer.write("h1{margin-top:30px;}");
            writer.write(".card{background:white;padding:20px;margin:20px auto;width:80%;box-shadow:0 2px 10px rgba(0,0,0,0.1);}");
            writer.write("</style>");

            writer.write("</head><body>");

            writer.write("<h1>Automation Performance Dashboard</h1>");

            writer.write("<div class='card'>");
            writer.write("<canvas id='chart'></canvas>");
            writer.write("</div>");

            writer.write("<div class='card'>");
            writer.write("<h2>Function Execution Summary</h2>");
            writer.write("<table border='1' style='margin:auto;border-collapse:collapse;'>");
            writer.write("<tr><th>Function</th><th>Average Time (sec)</th><th>Total Executions</th></tr>");

            for (int i = 0; i < functions.size(); i++) {

                writer.write("<tr>");
                writer.write("<td>" + functions.get(i) + "</td>");
                writer.write("<td>" + avgTimes.get(i) + "</td>");
                writer.write("<td>" + executions.get(i) + "</td>");
                writer.write("</tr>");
            }

            writer.write("</table>");
            writer.write("</div>");

            writer.write("<script>");

            writer.write("const labels = " + functions.toString() + ";");
            writer.write("const data = " + avgTimes.toString() + ";");

            writer.write(
                    "new Chart(document.getElementById('chart'), {" +
                            "type: 'bar'," +
                            "data: {" +
                            "labels: labels," +
                            "datasets: [{" +
                            "label: 'Average Execution Time (seconds)'," +
                            "data: data," +
                            "backgroundColor: 'green'" +
                            "}]" +
                            "}," +
                            "options: {" +
                            "responsive:true," +
                            "plugins:{legend:{display:true}}," +
                            "scales:{y:{beginAtZero:true}}" +
                            "}" +
                            "});"
            );

            writer.write("</script>");

            writer.write("</body></html>");

            writer.close();

            System.out.println("✅ Performance dashboard generated: " + htmlFile);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}