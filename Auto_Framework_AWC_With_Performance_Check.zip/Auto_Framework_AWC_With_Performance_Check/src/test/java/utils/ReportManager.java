package utils;

public class ReportManager {
    public static String latestReportPath;
}
