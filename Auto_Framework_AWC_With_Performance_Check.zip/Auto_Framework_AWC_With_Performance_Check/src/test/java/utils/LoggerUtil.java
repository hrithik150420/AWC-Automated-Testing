package utils;

import listeners.ExtentTestListener;

public class LoggerUtil {

    public static void info(String message) {
        ExtentTestListener.getTest().info(message);
    }

    public static void pass(String message) {
        ExtentTestListener.getTest().pass(message);
    }

    public static void fail(String message) {
        ExtentTestListener.getTest().fail(message);
    }
}
