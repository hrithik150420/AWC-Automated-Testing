package utils;

import java.sql.*;
import java.io.*;
import java.util.*;

public class DashboardGenerator {

    public static void generateDashboard() {

        String db = "jdbc:sqlite:performance.db";
        String html = "performance_dashboard.html";

        Map<String,List<Double>> map = new LinkedHashMap<>();

        try {

            Connection conn = DriverManager.getConnection(db);

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT function,time FROM performance");

            while(rs.next()){

                String fn = rs.getString("function");

                double sec = rs.getDouble("time") / 1000;

                map.putIfAbsent(fn,new ArrayList<>());
                map.get(fn).add(sec);
            }

            FileWriter writer = new FileWriter(html);

            writer.write("<html><head>");
            writer.write("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");
            writer.write("</head><body>");

            writer.write("<h1>Automation Performance Dashboard</h1>");
            writer.write("<canvas id='chart'></canvas>");

            List<String> functions = new ArrayList<>();
            List<Double> avg = new ArrayList<>();

            for(String fn:map.keySet()){

                List<Double> times = map.get(fn);

                double sum=0;

                for(double t:times) sum+=t;

                double a = sum/times.size();

                functions.add("'"+fn+"'");
                avg.add(a);
            }

            writer.write("<script>");

            writer.write("const labels=["+String.join(",",functions)+"];");
            writer.write("const data="+avg.toString()+";");

            writer.write(
            "new Chart(document.getElementById('chart'),{" +
            "type:'bar'," +
            "data:{labels:labels,datasets:[{label:'Avg Time (sec)',data:data}]}" +
            "});"
            );

            writer.write("</script>");
            writer.write("</body></html>");

            writer.close();

            System.out.println("Dashboard Generated");

        } catch(Exception e){

            e.printStackTrace();
        }
    }
}