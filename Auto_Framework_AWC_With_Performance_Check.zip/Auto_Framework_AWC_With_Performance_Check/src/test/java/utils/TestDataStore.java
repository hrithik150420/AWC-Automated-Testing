package utils;

public class TestDataStore {

    public static String createdItemID;
    public static String createdItemName;

}