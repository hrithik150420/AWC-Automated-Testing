package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {

    public static Properties prop;

    static {

        try {

            prop = new Properties();
            FileInputStream fis = new FileInputStream("config.properties");
            prop.load(fis);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getProperty(String key) {
        return prop.getProperty(key);
    }

    public static Properties initProperties() {
        prop = new Properties();
        try {
            FileInputStream ip = new FileInputStream("src/test/resources/config.properties");
            prop.load(ip);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return prop;
    }
}
