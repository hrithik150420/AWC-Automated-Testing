package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

    private static ExtentReports extent;

    public static ExtentReports getExtentReport() {

        if (extent == null) {

            String reportPath =
                    "test-output/ExtentReport_" + ReportUtil.getTimeStamp() + ".html";

            System.out.println("Creating report at: " + reportPath);

            ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);

            extent = new ExtentReports();
            extent.attachReporter(spark);

            ReportManager.latestReportPath = reportPath;
        }

        return extent;
    }
}
