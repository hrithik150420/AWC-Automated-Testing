package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ReportUtil {
    public static String getTimeStamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
    }
}
