package utils;

import java.sql.*;
import java.io.*;
import java.util.*;

public class AdvancedDashboardGenerator {

    public static void generateDashboard() {

        String db = "jdbc:sqlite:performance.db";
        String html = "performance_dashboard.html";

        Map<String,List<Double>> map = new LinkedHashMap<>();

        try {

            Connection conn = DriverManager.getConnection(db);

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(
            "SELECT function, AVG(time)/1000 as avgTime, MAX(time)/1000 as latestTime FROM performance GROUP BY function");

            List<String> functions = new ArrayList<>();
            List<Double> avgTimes = new ArrayList<>();

            while(rs.next()){

                String fn = rs.getString("function");
                double avg = rs.getDouble("avgTime");

                functions.add("'"+fn+"'");
                avgTimes.add(avg);
            }

            FileWriter writer = new FileWriter(html);

            writer.write("<html><head>");
            writer.write("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");
            writer.write("</head><body style='font-family:Arial'>");

            writer.write("<h1>Automation Performance Analytics</h1>");

            writer.write("<div style='width:800px;margin:auto'>");
            writer.write("<canvas id='barChart'></canvas>");
            writer.write("</div>");

            writer.write("<div style='width:400px;margin:auto;margin-top:40px'>");
            writer.write("<canvas id='pieChart'></canvas>");
            writer.write("</div>");

            writer.write("<script>");

            writer.write("const labels=["+String.join(",",functions)+"];");
            writer.write("const data="+avgTimes.toString()+";");

            writer.write(
            "new Chart(document.getElementById('barChart'),{" +
            "type:'bar'," +
            "data:{labels:labels,datasets:[{" +
            "label:'Average Execution Time (sec)'," +
            "data:data," +
            "options:{responsive:true,maintainAspectRatio:false}"+
            "backgroundColor:data.map(v=>v>5?'red':'green')" +
            "}]}," +
            "options:{responsive:true}" +
            "});"
            );

            writer.write(
            "new Chart(document.getElementById('pieChart'),{" +
            "type:'pie'," +
            "data:{labels:['Fast','Slow']," +
            "datasets:[{data:[" +
            avgTimes.stream().filter(t->t<=5).count() + "," +
            avgTimes.stream().filter(t->t>5).count() +
            "]}]}" +
            "});"
            );

            writer.write("<canvas id='barChart' height='120'></canvas>");
            writer.write("<canvas id='pieChart' height='200'></canvas>");

            writer.write("</script>");
            writer.write("</body></html>");

            writer.close();

            conn.close();

            System.out.println("Advanced Performance Dashboard Generated");

        } catch(Exception e){

            e.printStackTrace();
        }
    }
}