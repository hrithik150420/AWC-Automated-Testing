package utils;

public class ActionPerformanceTracker {

    public static void track(String actionName, Runnable action) {

        long start = System.currentTimeMillis();

        action.run();

        long end = System.currentTimeMillis();

        long duration = end - start;

        System.out.println(actionName + " took: " + duration + " ms");
    }
}