package utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class PerformanceUtil {

    // Measure page load time
    public static long getPageLoadTime(WebDriver driver) {

        JavascriptExecutor js = (JavascriptExecutor) driver;

        long navigationStart = (Long) js.executeScript(
                "return window.performance.timing.navigationStart");

        long loadEventEnd = (Long) js.executeScript(
                "return window.performance.timing.loadEventEnd");

        return (loadEventEnd - navigationStart);
    }

    // Measure action execution time (existing method)
    public static long measureAction(Runnable action) {

        long startTime = System.currentTimeMillis();

        action.run();

        long endTime = System.currentTimeMillis();

        return endTime - startTime;
    }

    // ⭐ NEW METHOD — Measure and automatically log performance
    public static void measure(String functionName, Runnable action) {

        long startTime = System.currentTimeMillis();

        try {
            action.run();
        }
        finally {

            long endTime = System.currentTimeMillis();

            long executionTime = endTime - startTime;

            // Log to database
            PerformanceLogger.log(functionName, executionTime);

            System.out.println(functionName + " executed in " + executionTime + " ms");
        }
    }
}