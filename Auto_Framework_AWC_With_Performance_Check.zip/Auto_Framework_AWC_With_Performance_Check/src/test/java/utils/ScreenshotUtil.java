package utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

public class ScreenshotUtil {

    public static String takeScreenshot(WebDriver driver, String testName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File src = ts.getScreenshotAs(OutputType.FILE);

            String dir = "test-output/screenshots";
            Files.createDirectories(Path.of(dir));

            String path = dir + "/" + testName + ".png";
            Files.copy(src.toPath(), Path.of(path));

            return path;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
