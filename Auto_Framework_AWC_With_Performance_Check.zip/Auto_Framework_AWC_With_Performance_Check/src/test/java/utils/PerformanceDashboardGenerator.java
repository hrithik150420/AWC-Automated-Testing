package utils;

import java.io.FileWriter;
import java.sql.*;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.*;

public class PerformanceDashboardGenerator {

    public static void generateDashboard() {

        String dbUrl = "jdbc:sqlite:performance.db";
        String htmlFile = "performance_dashboard.html";

        DecimalFormat df = new DecimalFormat("#.##");

        try (Connection conn = DriverManager.getConnection(dbUrl)) {

            Statement stmt = conn.createStatement();

            Map<String, List<Double>> functionTimes = new LinkedHashMap<>();
            Map<String, Double> latestTimes = new LinkedHashMap<>();

            Map<String, Map<String, Double>> rawHeatmap = new LinkedHashMap<>();
            List<String> runTimestamps = new ArrayList<>();


            /*
            Fetch last 8 run timestamps
             */

            ResultSet runResult = stmt.executeQuery(
                    "SELECT run_id, MIN(timestamp) as ts " +
                    "FROM performance GROUP BY run_id " +
                    "ORDER BY run_id DESC LIMIT 8");

            Map<Integer,String> runMap = new LinkedHashMap<>();

            while (runResult.next()) {

                int runId = runResult.getInt("run_id");
                String ts = runResult.getString("ts");

                runMap.put(runId, ts);
                runTimestamps.add(ts);
            }

            Collections.reverse(runTimestamps);

            /*
            Fetch performance data
             */

            ResultSet rs = stmt.executeQuery(
                    "SELECT function,time,run_id,timestamp FROM performance");

            while (rs.next()) {

                String function = rs.getString("function");
                double time = rs.getLong("time") / 1000.0;
                int runId = rs.getInt("run_id");
                String ts = runMap.get(runId);

                if(ts == null)
                    continue;

                functionTimes.putIfAbsent(function,new ArrayList<>());
                functionTimes.get(function).add(time);

                if(runId == Collections.max(runMap.keySet())){
                    latestTimes.put(function,time);
                }

                rawHeatmap.putIfAbsent(function,new LinkedHashMap<>());
                rawHeatmap.get(function).put(ts,time);
            }


            /*
            Average calculation
             */

            Map<String,Double> avgTimes = new LinkedHashMap<>();

            for(String func : functionTimes.keySet()){

                List<Double> times = functionTimes.get(func);

                double avg = times.stream()
                        .mapToDouble(Double::doubleValue)
                        .average()
                        .orElse(0);

                avgTimes.put(func,avg);
            }


            /*
            Sort slowest functions
             */

            List<Map.Entry<String,Double>> slowest =
                    new ArrayList<>(avgTimes.entrySet());

            slowest.sort((a,b)->Double.compare(b.getValue(),a.getValue()));


            /*
            Heatmap preparation
             */

            Map<String,List<Double>> heatmapData = new LinkedHashMap<>();

            for(String func : rawHeatmap.keySet()){

                List<Double> times = new ArrayList<>();

                for(String ts : runTimestamps){
                    times.add(rawHeatmap.get(func).getOrDefault(ts,0.0));
                }

                heatmapData.put(func,times);
            }


            String buildId = ConfigReader.getProperty("Build");
            String generated = LocalDateTime.now().toString();

            FileWriter writer = new FileWriter(htmlFile);

            writer.write("<html><head>");
            writer.write("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");

            writer.write("<style>");
            writer.write("body{font-family:Arial;background:#f4f6f8;text-align:center;}");
            writer.write(".card{background:white;padding:25px;margin:30px auto;width:85%;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.1);}");
            writer.write("table{border-collapse:collapse;width:80%;margin:auto;font-size:15px;}");
            writer.write("th,td{border:1px solid #ddd;padding:10px;text-align:center;}");
            writer.write("th{background:#2c3e50;color:white;}");
            writer.write("</style>");

            writer.write("</head><body>");

            writer.write("<h1>Automation Performance Dashboard</h1>");
            writer.write("<h3>Build: "+buildId+"</h3>");
            writer.write("<h4>Generated: "+generated+"</h4>");


            /*
            Average Chart
             */

            writer.write("<div class='card'>");
            writer.write("<h2>Average Execution Time</h2>");
            writer.write("<canvas id='avgChart'></canvas>");
            writer.write("</div>");


            /*
            Execution Summary
             */

            writer.write("<div class='card'>");
            writer.write("<h2>Execution Summary</h2>");

            writer.write("<table>");
            writer.write("<tr><th>Function</th><th>Average (s)</th><th>Latest (s)</th><th>Status</th></tr>");

            for(String func : avgTimes.keySet()){

                double avg = avgTimes.get(func);
                double latest = latestTimes.getOrDefault(func,0.0);

                String status;
                String color;

                if(!latestTimes.containsKey(func)){
                    status="Not Executed";
                    color="#f39c12";
                }
                else if(latest > avg*1.2){
                    status="Slower";
                    color="#c0392b";
                }
                else if(latest < avg*0.9){
                    status="Improved";
                    color="#27ae60";
                }
                else{
                    status="Stable";
                    color="#34495e";
                }

                writer.write("<tr>");
                writer.write("<td>"+func+"</td>");
                writer.write("<td>"+df.format(avg)+"</td>");
                writer.write("<td>"+(latest==0?"-":df.format(latest))+"</td>");
                writer.write("<td style='background:"+color+";color:white;font-weight:bold'>"+status+"</td>");
                writer.write("</tr>");
            }

            writer.write("</table>");
            writer.write("</div>");


            /*
            Heatmap
             */

            writer.write("<div class='card'>");
            writer.write("<h2>Performance Heatmap (Last 8 Runs)</h2>");

            writer.write("<table>");
            writer.write("<tr><th>Function</th>");

            for(String ts : runTimestamps){
                writer.write("<th>"+ts+"</th>");
            }

            writer.write("</tr>");

            for(String func : heatmapData.keySet()){

                writer.write("<tr>");
                writer.write("<td>"+func+"</td>");

                List<Double> times = heatmapData.get(func);
                double avg = times.stream().mapToDouble(Double::doubleValue).average().orElse(0);

                for(Double t : times){

                    String color="#ecf0f1";

                    if(t > avg*1.2) color="#c0392b";
                    else if(t < avg*0.9 && t!=0) color="#27ae60";

                    writer.write("<td style='background:"+color+"'>"+
                            (t==0?"-":df.format(t))+"</td>");
                }

                writer.write("</tr>");
            }

            writer.write("</table>");
            writer.write("</div>");

            /*
            Top 3 Slowest Functions
             */

            writer.write("<div class='card'>");
            writer.write("<h2>Top 3 Slowest Functions</h2>");

            writer.write("<table>");
            writer.write("<tr><th>Rank</th><th>Function</th><th>Average (s)</th></tr>");

            for(int i=0;i<Math.min(3,slowest.size());i++){

                Map.Entry<String,Double> entry = slowest.get(i);

                writer.write("<tr>");
                writer.write("<td>"+(i+1)+"</td>");
                writer.write("<td>"+entry.getKey()+"</td>");
                writer.write("<td>"+df.format(entry.getValue())+"</td>");
                writer.write("</tr>");
            }

            writer.write("</table>");
            writer.write("</div>");


            /*
            Chart data
             */

            StringBuilder labels=new StringBuilder("[");
            StringBuilder data=new StringBuilder("[");
            StringBuilder colors=new StringBuilder("[");

            int i=0;

            for(String func : avgTimes.keySet()){

                if(i>0){labels.append(",");data.append(",");colors.append(",");}

                labels.append("'").append(func).append("'");
                data.append(avgTimes.get(func));

                double avg = avgTimes.get(func);
                double latest = latestTimes.getOrDefault(func,0.0);

                if(latest > avg*1.2) colors.append("'#c0392b'");
                else colors.append("'#8B4513'");

                i++;
            }

            labels.append("]");
            data.append("]");
            colors.append("]");

            writer.write("<script>");
            writer.write("new Chart(document.getElementById('avgChart'),{");
            writer.write("type:'bar',");
            writer.write("data:{labels:"+labels+",datasets:[{data:"+data+",backgroundColor:"+colors+",borderRadius:8}]},");
            writer.write("options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}");
            writer.write("});");
            writer.write("</script>");

            writer.write("</body></html>");

            writer.close();

            System.out.println("Performance Dashboard Generated → "+htmlFile);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}