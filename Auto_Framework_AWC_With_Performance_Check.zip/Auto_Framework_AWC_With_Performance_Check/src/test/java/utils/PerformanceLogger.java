package utils;

import java.sql.*;

public class PerformanceLogger {

    private static final String DB_URL = "jdbc:sqlite:performance.db";

    private static int runId = (int)(System.currentTimeMillis()/1000);

    public static void createTableIfNotExists() {

        try {

            Connection conn = DriverManager.getConnection(DB_URL);

            Statement stmt = conn.createStatement();

            String sql = "CREATE TABLE IF NOT EXISTS performance (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "run_id INTEGER," +
                    "function TEXT," +
                    "time INTEGER," +
                    "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ");";

            stmt.execute(sql);

            stmt.close();
            conn.close();

            System.out.println("Performance table ready");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void log(String function, long time) {

        try {

            Connection conn = DriverManager.getConnection(DB_URL);

            String sql = "INSERT INTO performance(run_id,function,time) VALUES(?,?,?)";

            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, runId);
            stmt.setString(2, function);
            stmt.setLong(3, time);

            stmt.executeUpdate();

            conn.close();

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}