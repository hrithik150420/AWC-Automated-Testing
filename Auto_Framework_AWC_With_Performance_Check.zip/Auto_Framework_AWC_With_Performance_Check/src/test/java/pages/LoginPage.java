package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.Setup_File;
import utils.ActionPerformanceTracker;

import java.time.Duration;

public class LoginPage extends Setup_File {

    WebDriver driver;
    WebDriverWait wait;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    By username = By.name("username");
    By password = By.name("password");
    By loginBtn = By.xpath("//button[@type='submit']");
    By profileBtn = By.cssSelector("button[aria-label='Your Profile']");

    public void login(String user, String pass) {
        driver.findElement(username).sendKeys(user);
        driver.findElement(password).sendKeys(pass);
        ActionPerformanceTracker.track("Click Login Button", () -> {
        driver.findElement(loginBtn).click();
    });     
        

    }

    
}
