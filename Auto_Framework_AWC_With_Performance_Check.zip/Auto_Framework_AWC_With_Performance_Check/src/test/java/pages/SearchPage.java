package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.Setup_File;
import utils.LoggerUtil;
import java.time.Duration;


public class SearchPage extends Setup_File{

    WebDriver driver;
    WebDriverWait wait;

    By searchBox = By.xpath("//input[@placeholder='Search']");
    By searchBtn = By.xpath("//span[@role='button' and @title='Search']");
    By categoryDropdown = By.xpath("//div[@aria-label='selectPrefilter2']");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void changeSearchCategory(String categoryName) {    
    // open dropdown
    wait.until(ExpectedConditions.elementToBeClickable(categoryDropdown)).click();

    // select category dynamically
    By categoryOption = By.xpath("//div[@class='sw-cell-valName' and @title='" + categoryName + "']");

    wait.until(ExpectedConditions.visibilityOfElementLocated(categoryOption));
    driver.findElement(categoryOption).click();

    }


    public void searchItem(String itemId, String category) {
        
        changeSearchCategory(category);
        By item = By.xpath("//label[contains(@title,'" + itemId + "')]");
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox)).sendKeys(itemId);

        int retry = 10;
        while (retry > 0) {
            driver.findElement(searchBtn).click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("aw-busy")));
             
            if (driver.findElements(item).size() > 0) {
                LoggerUtil.pass("Search result found for item: " + itemId);
                return;
            }
            retry--;
            LoggerUtil.info("Retrying search... Attempts left: " + retry);
        }

        LoggerUtil.fail("Item not found after multiple attempts: " + itemId);
    }

    public void openSearchedResult(String itemId) {

        By item = By.xpath("//label[@title='" + itemId + "']");
        By openBtn = By.xpath("//span[@icon-id='cmdOpen']/ancestor::button");
        By open = By.cssSelector("li[button-id='Awp0ShowObject']");
        By objectHeader = By.xpath("//div[contains(@title,'" + itemId + "')]");

        wait.until(ExpectedConditions.elementToBeClickable(item)).click();        
        wait.until(ExpectedConditions.elementToBeClickable(openBtn)).click();       
        wait.until(ExpectedConditions.elementToBeClickable(open)).click();

        // 🔥 Wait until object page loads using partial title
        if (wait.until(ExpectedConditions.visibilityOfElementLocated(objectHeader)) != null) {
            LoggerUtil.pass("Successfully opened item: " + itemId);
        }
        else
        {
            LoggerUtil.fail("Failed to open item: " + itemId);
        }
    }


}
