package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

import utils.LoggerUtil;

public class UserSettingsPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public UserSettingsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    // ============================================================
    // 🔹 HEADER DROPDOWN LOCATORS (AWC Stable)
    // ============================================================

    private By profileBtn =
        By.cssSelector("button[aria-label='Your Profile']");

    private By roleDropdown =
            By.cssSelector("div[data-locator='aw-state-userRole']");

    private By groupDropdown =
            By.cssSelector("div[data-locator='aw-state-userGroup']");

    private By projectDropdown =
            By.cssSelector("div[data-locator='aw-state-userProject']");

    private By logoutDropdown =
            By.cssSelector("div[data-locator='aw-state-userName']");

    private By logoutBtn =
            By.cssSelector("[button-id='cmdSignOut']");


    // ============================================================
    // 🔹 MAIN METHOD (NULL SAFE)
    // ============================================================

    public void changeUserSettings(String group, String role, String project) {

        if (isBlank(group) && isBlank(role) && isBlank(project)) {
            LoggerUtil.info("No user setting values provided. Skipping change.");
            return;
        }

        openProfileMenu();

        if (!isBlank(group)) {
            if (!wait.until(ExpectedConditions.visibilityOfElementLocated(logoutBtn)).isDisplayed()) {
                openProfileMenu();
            }
            selectFromHeaderDropdown(groupDropdown, group);
        }

        if (!isBlank(role)) {
            if (!wait.until(ExpectedConditions.visibilityOfElementLocated(logoutBtn)).isDisplayed()) {
                openProfileMenu();
            }
            selectFromHeaderDropdown(roleDropdown, role);
        }

        if (!isBlank(project)) {
            if (!wait.until(ExpectedConditions.visibilityOfElementLocated(logoutBtn)).isDisplayed()) {
                openProfileMenu();
            }
            selectFromHeaderDropdown(projectDropdown, project);
            LoggerUtil.info("Project changed to: " + project);
        }

        waitForPageReload();

        LoggerUtil.pass("User settings updated successfully");
    }


    // ============================================================
    // 🔹 LOGOUT
    // ============================================================

    public void logout() {

        wait.until(ExpectedConditions.elementToBeClickable(logoutDropdown)).click();

        try {
            wait.until(ExpectedConditions.elementToBeClickable(logoutBtn)).click();
            LoggerUtil.pass("User logged out successfully");
            waitForPageReload();
        } catch (Exception e) {
            LoggerUtil.fail("Failed to click logout button");
        }

    }


    // ============================================================
    // 🔹 REUSABLE DROPDOWN METHOD
    // ============================================================

    private void selectFromHeaderDropdown(By dropdownLocator, String value) {

        // 1️⃣ Click dropdown (e.g. Planner)
        wait.until(ExpectedConditions.elementToBeClickable(dropdownLocator)).click();

        // 2️⃣ Select option from popup
        By option = By.xpath("//div[@data-locator='aw-popup-cellContentContainer']//span[normalize-space()='" + value + "']");

        try {
            wait.until(ExpectedConditions.elementToBeClickable(option)).click();
            LoggerUtil.pass(value + " selected from dropdown");
        } catch (Exception e) {
            LoggerUtil.fail("Failed to select: " + value + "from dropdown.");
        }
    }

    public void openProfileMenu() {

    wait.until(ExpectedConditions.elementToBeClickable(profileBtn)).click();
        if (wait.until(ExpectedConditions.visibilityOfElementLocated(logoutBtn)).isDisplayed()) {
            LoggerUtil.info("Profile menu opened successfully");
        } else {
            LoggerUtil.info("Failed to open profile menu");
        }
    LoggerUtil.info("Profile menu opened");
    }


    // ============================================================
    // 🔹 UTIL METHODS
    // ============================================================

    private void waitForPageReload() {
        wait.until(driver ->
                ((JavascriptExecutor) driver)
                        .executeScript("return document.readyState")
                        .equals("complete"));
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}