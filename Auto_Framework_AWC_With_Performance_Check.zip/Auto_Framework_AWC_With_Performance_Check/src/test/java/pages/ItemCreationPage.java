package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.Setup_File;
import utils.LoggerUtil;
import utils.TestDataStore;

public class ItemCreationPage {

    WebDriver driver;
    WebDriverWait wait;

    public ItemCreationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    // Locators 
    By addBtn = By.xpath("//button[@aria-label='Add']");
    By createItemOption = By.id("createItem");
    //By itemTypeDropdown = By.id(prop.getProperty("itemType"));
    By itemIdField = By.xpath("//input[@aria-label='ID']");
    By itemNameField = By.xpath("//textarea[@aria-label='Name']");
    By itemDescrpField = By.xpath("//textarea[@aria-label='Description']");
    By saveBtn = By.xpath("//div[contains(@class,'aw-panel-footer')]//button[.//div[normalize-space()='Add']]");
    
    By successMsg = By.xpath("//span[contains(text(),'was added.')]");

    // Click Create → Item
    public void openCreateItem() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(addBtn)).click();
            LoggerUtil.pass("Create Item option clicked");
        } catch (Exception e) {
            LoggerUtil.fail("Failed to click Create Item option");
        }
    }

    // Select Item Type (example: Part)
    public void selectItemType(String itemType) {

        By itemTypeDropdown = By.xpath("//div[@title='" + itemType + "']");
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(itemTypeDropdown)).click();
            LoggerUtil.pass("Item type selected as: " + itemType);
        } catch (Exception e) {
            LoggerUtil.fail("Failed to select item type: " + itemType);
        }
    }

    // Enter Item details
    public void enterItemDetails(String itemId, String itemName) {

        String randomNumber = Setup_File.generateRandomNumber();
        String ItemID = driver.findElement(itemIdField).getAttribute("value").trim();
        TestDataStore.createdItemID = ItemID;
        
        driver.findElement(itemNameField).sendKeys(itemName + " - " + randomNumber);
        driver.findElement(itemDescrpField).sendKeys(itemName);
        TestDataStore.createdItemName = itemName + " - " + randomNumber;
        if (driver.findElement(saveBtn).isEnabled()) {
            LoggerUtil.pass("Item details entered with ID: " + ItemID + " and Name: " + itemName + " - " + randomNumber);
        } else {
            LoggerUtil.fail("Save button is not enabled after entering item details");
        }
        
    }

    // Save Item
    public boolean addItem() {
        driver.findElement(saveBtn).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(successMsg));
        return driver.findElement(successMsg).isDisplayed();
    }

    public void createPart(String itemId, String itemName) {

        openCreateItem();
        selectItemType(itemId);
        enterItemDetails(itemId, itemName);
        if (addItem()) {
            LoggerUtil.pass("Part created successfully");
        } else {
            LoggerUtil.fail("Failed to create part");
        }
    }

}
