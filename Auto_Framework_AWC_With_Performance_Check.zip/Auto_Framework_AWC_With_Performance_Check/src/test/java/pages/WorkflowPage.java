package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;

import utils.LoggerUtil;

public class WorkflowPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Constructor
    public WorkflowPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    // 🔹 Locators
    private By initiateWorkflowBtn =
            By.cssSelector("[button-id='Awp0StartWorkflow']");

    private By moreMenuBtn =
            By.cssSelector("[button-id='Awp0MoreGroup']");

    private By ManageBtn =
            By.cssSelector("[button-id='Awp0ManageGroup']");

    private By SubmitToWorkflowBtn =
            By.cssSelector("[iconid='cmdSubmitToWorkflow']");

    //private By allRadio = By.xpath("//span[normalize-space()='All']");

    private By successMsg = By.xpath("//span[contains(text(),'was submitted to workflow.')]");
    private By submittBtn = By.xpath("//button[.//div[text()='Submit']]");

    public void startWorkflow(String templateName) {

        clickInitiateWorkflowFromMoreMenu();
        selectWorkflowTemplate(templateName);
        clickStart(templateName);
    }

    // 🔹 Click Initiate Workflow
    public void clickInitiateWorkflow() {

        WebElement element = wait.until(
                ExpectedConditions.elementToBeClickable(initiateWorkflowBtn)
        );

        try {
            element.click();
            LoggerUtil.info("Initiate Workflow button clicked successfully");
        } catch (Exception e) {
            LoggerUtil.fail("Failed to click Initiate Workflow button");
        }
    }

    // 🔹 If workflow is under overflow (three dots)
    public void clickInitiateWorkflowFromMoreMenu() {

        wait.until(ExpectedConditions.elementToBeClickable(moreMenuBtn)).click();

        wait.until(ExpectedConditions.elementToBeClickable(ManageBtn)).click();

        try {
            wait.until(ExpectedConditions.elementToBeClickable(SubmitToWorkflowBtn)).click();
            LoggerUtil.info("Initiate Workflow clicked from More menu");
        } catch (Exception e) {
            LoggerUtil.fail("Failed to click Initiate Workflow from More menu");
        }
    }

    // 🔹 Select Workflow Template
    public boolean selectWorkflowTemplate(String templateName) {

        By templateField = By.xpath("//input[@aria-label='Template']");
        wait.until(ExpectedConditions.elementToBeClickable(templateField)).click();
        wait.until(ExpectedConditions.elementToBeClickable(templateField)).sendKeys(templateName);

        By template = By.xpath("//div[contains(@title,'" + templateName + "')]");
        
        try {
            wait.until(ExpectedConditions.elementToBeClickable(template)).click();
            LoggerUtil.info(templateName + ": Workflow template selected");
            return true;
        } catch (Exception e) {
            LoggerUtil.fail("Failed to select workflow template: " + templateName);
            return false;
        }
    }

    // 🔹 Click Start
    public void clickStart(String templateName) {
        wait.until(ExpectedConditions.elementToBeClickable(submittBtn)).click();
        if(wait.until(ExpectedConditions.visibilityOfElementLocated(successMsg)) != null) {
            LoggerUtil.pass(templateName + ": Workflow started successfully");
        }
        else {
             LoggerUtil.fail("Failed to start workflow: " + templateName);
        }
    }
}