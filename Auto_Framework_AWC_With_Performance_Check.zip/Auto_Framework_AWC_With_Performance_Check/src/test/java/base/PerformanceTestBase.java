package base;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.ITestResult;
import utils.PerformanceLogger;
import utils.PerformanceReportGenerator;
import utils.PerformanceDashboardGenerator;

public class PerformanceTestBase extends Setup_File {

    private long startTime;

    @BeforeMethod
    public void startTimer() {

        startTime = System.currentTimeMillis();

    }

    @AfterMethod
    public void stopTimer(ITestResult result) {

        long endTime = System.currentTimeMillis();

        long duration = endTime - startTime;

        String testName = result.getMethod().getMethodName();

        System.out.println(testName + " Execution Time: " + duration + " ms");

        PerformanceLogger.log(testName, duration);

    }

    @AfterSuite
    public void generatePerformanceDashboard() {

        PerformanceReportGenerator.generateReport();

    }

    @AfterSuite
    public void generateReport() {
    PerformanceDashboardGenerator.generateDashboard();

    }
}