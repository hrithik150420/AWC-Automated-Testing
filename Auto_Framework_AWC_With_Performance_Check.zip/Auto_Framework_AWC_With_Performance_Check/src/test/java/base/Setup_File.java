package base;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import pages.LoginPage;
import utils.AdvancedDashboardGenerator;
import utils.ConfigReader;
import utils.DashboardGenerator;
import utils.LoggerUtil;
import utils.PerformanceDashboardGenerator;
import utils.PerformanceLogger;
import listeners.ExtentTestListener;
import com.aventstack.extentreports.ExtentTest;
import java.util.Random;
import java.time.Duration;
import java.util.Properties;

public class Setup_File {

    public WebDriver driver;
    public WebDriverWait wait;
    protected Properties prop;
    private By profileBtn =
        By.cssSelector("button[aria-label='Your Profile']");

    @BeforeClass
    public void setUp() {

        // 1️⃣ Initialize properties first
        prop = ConfigReader.initProperties();

        // 2️⃣ Launch browser
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // 3️⃣ Implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        // 4️⃣ Initialize explicit wait AFTER driver creation
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @BeforeSuite
    public void initPerformanceDB() {
    PerformanceLogger.createTableIfNotExists();

    }


    protected String getConfig(String key) {
        return prop.getProperty(key);
    }
    

    // -----------------------------
    // 🔹 REUSABLE Random Number METHODS
    // -----------------------------
    public static String generateRandomNumber() {

        Random random = new Random();
        int number = 10000 + random.nextInt(90000);

        return String.valueOf(number);
    }
    

    // -----------------------------
    // 🔹 REUSABLE WAIT METHODS
    // -----------------------------

    protected WebElement waitForElement(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    protected void waitForPageLoad() {
        wait.until(driver ->
                ((JavascriptExecutor) driver)
                        .executeScript("return document.readyState")
                        .equals("complete"));
    }

    // -----------------------------
    // 🔹 LOGGING METHODS
    // -----------------------------

    protected void logInfo(String message) {
        ExtentTest test = ExtentTestListener.getTest();
        if (test != null) {
            test.info(message);
        }
    }

    protected void logPass(String message) {
        ExtentTest test = ExtentTestListener.getTest();
        if (test != null) {
            test.pass(message);
        }
    }

    // -----------------------------
    // 🔹 REUSABLE LOGIN METHOD
    // -----------------------------

    protected void loginToActiveWorkspace() {

        driver.get(prop.getProperty("url"));

        // 1️⃣ Wait for DOM
        waitForPageLoad();
        logPass("Application URL opened successfully");

        // 2️⃣ Wait for Login Page element (IMPORTANT)
        if (waitForElement(By.name("username")).isDisplayed()) {
            logPass("Login page loaded successfully");
        } else {
            logInfo("Login page did not load properly");
        }
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                prop.getProperty("username"),
                prop.getProperty("password")
        );

        waitForPageLoad();
        // Wait for profile button to confirm login success
        //HomePage homePage = new HomePage(driver);
        if (waitForElement(profileBtn).isDisplayed()) {
            LoggerUtil.pass("Login successful");
        } else {
            LoggerUtil.fail("Login failed");
        }

        

    }


    // -----------------------------
    // 🔹 CLOSE BROWSER
    // -----------------------------

    @AfterClass
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }

   /*  @AfterSuite
    public void generateDashboard() {
        PerformanceReportGenerator.generateReport();
    }*/

    //@AfterSuite
    public void generateDashboard() {
        DashboardGenerator.generateDashboard();
    }

    //@AfterSuite
    public void generatePerformanceReport(){

    AdvancedDashboardGenerator.generateDashboard();

    }

    @AfterSuite
    public void generateReport() {
    PerformanceDashboardGenerator.generateDashboard();

}

    public void onExecutionFinish() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'onExecutionFinish'");
    }

    
}
