package listeners;

import base.Setup_File;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import utils.ExtentManager;
import utils.ScreenshotUtil;
import java.awt.Desktop;
import java.io.File;


public class ExtentTestListener implements ITestListener {

    private static ExtentReports extent;
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    // ✅ ADD THIS BACK
    public static ExtentTest getTest() {
        return test.get();
    }

    @Override
    public void onStart(ITestContext context) {
        extent = ExtentManager.getExtentReport();
        System.out.println("Extent Report initialized");
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest extentTest =
                extent.createTest(result.getMethod().getMethodName());
        test.set(extentTest);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        test.get().pass("Test Passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {

        Object testClass = result.getInstance();
        WebDriver driver;
        driver = ((Setup_File) testClass).driver;

        String screenshotPath =
                ScreenshotUtil.takeScreenshot(driver, result.getMethod().getMethodName());

        test.get().fail(result.getThrowable());

        if (screenshotPath != null) {
            test.get().addScreenCaptureFromPath(screenshotPath);
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        test.get().skip("Test Skipped");
    }

    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();
            System.out.println("Extent Report flushed");
        }
        // 🔥 AUTO OPEN REPORT (LOCAL ONLY)
        try {
            String reportPath = utils.ReportManager.latestReportPath;

            if (reportPath != null) {
                File report = new File(reportPath);
                System.out.println("Opening report: " + report.getAbsolutePath());

                if (report.exists() && Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(report.toURI());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
