package listeners;

import base.Setup_File;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import utils.PerformanceDashboardGenerator;
import utils.PerformanceReportGenerator;
import utils.ScreenshotUtil;

public class TestListener extends Setup_File implements ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {
        ScreenshotUtil.takeScreenshot(driver, result.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        PerformanceReportGenerator.generateReport();
        PerformanceDashboardGenerator.generateDashboard();
    }
}
