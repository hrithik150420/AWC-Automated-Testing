package org.QA;

public class Main {

    public static void main(String[] args) {

        System.out.println("Automation project started");
        System.out.println("Running Selenium framework");
    }
}
